<div class="col-lg-4 col-md-4 col-sm-4">
		<div class="row page-content-site">
			<div class="col-lg-12 col-md-12 col-sm-12">	
			<div class="h3">&nbsp;</div>
				<div class="row">
					<div class="col-lg-12" style="min-height:435px;">
						<!-- Responsive Header -->                                       
						<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>						
						<ins class="adsbygoogle"
							 style="display:block"
							 data-ad-client="ca-pub-1169273815439326"
							 data-ad-slot="1311700855"
							 data-ad-format="auto"></ins>
						<script>
						(adsbygoogle = window.adsbygoogle || []).push({});
						</script>                                        
					</div>         
				</div>
			</div>
		</div>
	</div>