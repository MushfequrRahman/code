<div id="header-2">
		<div class="container">
		<div class="default-nav-wrapper col-md-12 col-xs-12"> 	
		   <nav id="site-navigation" class="main-navigation" role="navigation">
	         <div id="nav-container">	
				<div class="menu-primari_menu-container"><ul id="menu-primari_menu" class="menu nav-menu"><li id="menu-item-40" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-40"><a href="http://techarise.com">Home</a></li>
</ul>
</li>
</ul></div>	          </div>  
			</nav><!-- #site-navigation -->
		  </div>		  
		</div>
	</div>