jQuery FullCalendar CRUD
========================
Basic CRUD (Create - Read - Update - Delete) functionality on jQuery FullCalendar using Codeigniter 3.0.3.

Dependencies (Included)
=======================
1. Twitter Bootstrap
2. <a href="https://github.com/jdewit/bootstrap-timepicker">Timepicker for Twitter Bootstrap</a>
3. <a href="https://github.com/mjolnic/bootstrap-colorpicker/">Bootstrap Colorpicker 2.0 for Twitter Bootstrap</a>

Instructions
============
 Use calendar.sql to build your database.


