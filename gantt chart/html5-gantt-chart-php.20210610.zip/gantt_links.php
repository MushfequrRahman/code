<?php
require_once '_db.php';

$stmt = $db->prepare("SELECT * FROM link");
$stmt->execute();
$items = $stmt->fetchAll();

class Link {}

$result = array();

foreach($items as $item) {
    $r = new Link();
    $r->id = $item['id'];
    $r->from = $item['from_id'];
    $r->to = $item['to_id'];
    $r->type = $item['type'];

    $result[] = $r;
}

header('Content-Type: application/json');
echo json_encode($result);
