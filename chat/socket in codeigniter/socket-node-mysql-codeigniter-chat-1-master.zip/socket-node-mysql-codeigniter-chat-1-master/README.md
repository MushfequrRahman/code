socket-node-mysql-codeigniter-chat
==================================

Real Time Chat using socket.io , node.js and codeigniter framework 
