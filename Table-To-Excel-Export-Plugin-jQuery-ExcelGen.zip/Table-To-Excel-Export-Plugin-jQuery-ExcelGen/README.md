<p align="center">
 <img width="467px" height="115" alt="js-excel-generator" src="https://i.imgur.com/Xw7Xfnv.png"/> 
</p>
<p align="center">
<b>A JavaScript Library for creating Excel Spreadsheets from HTML Tables</b>
</p>
Small HTML JavaScript Library which can be used to create Excel Spreadsheets 
from HTML Tables.  This project is in its very early stages. Documentation, 
additions and refinements to the library will be made very soon.  If you would 
like to try it out before then, please give this demo a try and 
figure out how it works.  Thanks! 

[Live Demo](https://rawgit.com/ecscstatsconsulting/js-excel-generator/master/demo.htm)

<p align="center">
 <img width="401px" height="106" alt="ecsc" src="https://i.imgur.com/SzVdycv.png"/> 
</p>
